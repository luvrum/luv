myVariableName = "John"
MyVariableName = "John"
my_variable_name = "John"