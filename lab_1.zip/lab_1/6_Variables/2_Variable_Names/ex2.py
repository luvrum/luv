#Illegal variables

# 2myvar = "John"
# my-var = "John"
# my var = "John"