x = 5
y = "John"
#error int + str can't 
print(x + y)