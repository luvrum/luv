x = "Python "
y = "is "
z = "awesome"
print(x + y + z)