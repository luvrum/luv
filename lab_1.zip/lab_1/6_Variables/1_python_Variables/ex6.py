a = 4
A = "Sally"
#A will not overwrite a