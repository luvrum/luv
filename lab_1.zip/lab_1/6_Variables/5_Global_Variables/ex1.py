x = "awesome"

def myfunc():
  print("Python is " + x)

myfunc()