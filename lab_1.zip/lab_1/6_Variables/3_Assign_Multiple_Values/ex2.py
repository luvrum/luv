x = y = z = "Orange"
print(x)
print(y)
print(z)