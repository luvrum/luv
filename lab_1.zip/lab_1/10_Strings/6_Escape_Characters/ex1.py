#error
#txt = "We are the so-called "Vikings" from the north."