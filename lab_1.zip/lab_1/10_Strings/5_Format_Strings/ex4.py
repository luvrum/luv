price = 59
txt = f"The price is {price:.2f} dollars"
print(txt)
