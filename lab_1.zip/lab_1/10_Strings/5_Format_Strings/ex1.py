age = 36
txt = "My name is John, I am " + age
#error
print(txt)