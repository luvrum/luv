price = 59
txt = f"The price is {price} dollars"
print(txt)
