txt = f"The price is {20 * 59} dollars"
print(txt)
