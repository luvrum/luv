age = 36
txt = f"My name is John, I am {age}"
print(txt)
