a = "Hello, World!"
print(a.split(",")) # returns ['Hello', ' World!']