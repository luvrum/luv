a = "Hello, World!"
print(a.upper())