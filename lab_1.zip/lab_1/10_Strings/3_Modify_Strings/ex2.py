a = "Hello, World!"
print(a.lower())