b = "Hello, World!"
print(b[2:5])