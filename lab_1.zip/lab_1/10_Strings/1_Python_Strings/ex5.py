a = "Hello, World!"
print(a[1])