a = "Hello, World!"
print(len(a))