a = "Hello"
print(a)