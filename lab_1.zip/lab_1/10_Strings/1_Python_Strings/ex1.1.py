print("It's alright")
print("He is called 'Johnny'")
print('He is called "Johnny"')
