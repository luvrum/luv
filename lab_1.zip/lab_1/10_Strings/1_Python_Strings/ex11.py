txt = "The best things in life are free!"
if "expensive" not in txt:
  print("No, 'expensive' is NOT present.")