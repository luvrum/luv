print("Hello")
print('Hello')