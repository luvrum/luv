txt = "The best things in life are free!"
if "free" in txt:
  print("Yes, 'free' is present.")