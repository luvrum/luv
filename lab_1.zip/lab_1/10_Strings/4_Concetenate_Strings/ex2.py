a = "Hello"
b = "World"
c = a + " " + b
print(c)