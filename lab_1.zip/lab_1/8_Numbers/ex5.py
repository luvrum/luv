x = 35e3
y = 12E4
z = -87.7e100

print(type(x))
print(type(y))
print(type(z))