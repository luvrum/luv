x = 3+5j
y = 5j
z = -5j

print(type(x))
print(type(y))
print(type(z))
