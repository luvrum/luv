x = 1
y = 2.8
z = 1j
print(type(x))
print(type(y))
print(type(z))